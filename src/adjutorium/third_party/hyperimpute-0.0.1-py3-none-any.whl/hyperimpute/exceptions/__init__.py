class StudyCancelled(Exception):
    pass


class BuildCancelled(Exception):
    pass
